var express = require('express');
var session = require('express-session');
var body_parser = require('body-parser');
var app = express();

app.use(body_parser.urlencoded({extended: true}));
app.use(express.static(__dirname + '/static'));
app.use(session({secret: 'codingisawesome'}));

app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function(request, response) {
    response.render("index");
});

app.post('/add_entry', function(request, response) {
    request.session.form = {name: request.body.name, location: request.body.location, fav_lang: request.body.fav_lang, comment: request.body.comment}; 
    response.redirect('/result');
    console.log(request.body);
    console.log("Reached add_entry");
    console.log(request.session.form);
});

app.get('/result', function(request, response) {
    response.render('result', {result: request.session.form})
    console.log("Reached result");
});

app.listen(8000, function() {
    console.log("Listening on port 8000");
});